<footer class="main-footer">
  <div class="container">
    <p class="copy">
      &copy; 2019 Adriana Santos. Todos os direitos reservados. Designed by <a href="https://mobspot.com.br" target="_blanck" >MobSpot</a><br>
      </a>
    </p>
  </div>
</footer>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-Y7WFE72BJ3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-Y7WFE72BJ3');
</script>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="js/runtime.js"></script>
<script type="text/javascript" src="js/vendors.js"></script>
<script type="text/javascript" src="js/main.js"></script>
<script type="text/javascript" src="js/amp.js"></script>
<script type="text/javascript" src="js/script-site.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>



